# Spanish Chatbot

## Overview

A web-based Spanish language chatbot application built with Flask that provides conversational interactions in Spanish. The chatbot uses pattern matching to recognize user inputs and respond with appropriate Spanish phrases for common conversational scenarios like greetings, farewells, questions about well-being, and expressions of gratitude.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask for server-side rendering
- **UI Framework**: Bootstrap with dark theme for responsive design
- **JavaScript**: Vanilla JavaScript class-based architecture for real-time chat interactions
- **Styling**: Custom CSS with Bootstrap overrides for chat-specific styling

### Backend Architecture
- **Web Framework**: Flask with minimal configuration for lightweight operation
- **Chatbot Logic**: Pattern-matching based conversational AI using regular expressions
- **Session Management**: Flask sessions with configurable secret key
- **API Design**: RESTful endpoints for chat message processing

### Chat System Design
- **Message Processing**: Regular expression pattern matching for Spanish language input
- **Response Generation**: Predefined response pools with random selection for natural conversation flow
- **UI Components**: Real-time message display with user/bot message differentiation
- **Character Limits**: Input validation and character counting for message length control

### Development Approach
- **Environment Configuration**: Environment variable support for deployment flexibility
- **Logging**: Debug-level logging for development and troubleshooting
- **Responsive Design**: Mobile-first approach with Bootstrap responsive utilities

## External Dependencies

### Frontend Libraries
- **Bootstrap**: CSS framework with dark theme variant from Replit CDN
- **Font Awesome**: Icon library for UI elements and visual indicators
- **Bootstrap JavaScript**: For interactive components like toasts and modals

### Backend Dependencies
- **Flask**: Web application framework
- **Python Standard Library**: Regular expressions (re) and logging modules

### Development Environment
- **Replit Platform**: Hosting and development environment integration
- **Environment Variables**: SESSION_SECRET for secure session management