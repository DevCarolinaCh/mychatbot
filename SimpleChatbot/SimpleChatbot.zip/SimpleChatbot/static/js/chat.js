/**
 * Spanish Chatbot - Frontend JavaScript
 * Handles real-time messaging and UI interactions
 */

class SpanishChatbot {
    constructor() {
        this.chatMessages = document.getElementById('chat-messages');
        this.chatForm = document.getElementById('chat-form');
        this.messageInput = document.getElementById('message-input');
        this.sendButton = document.getElementById('send-button');
        this.charCounter = document.getElementById('char-counter');
        this.loadingIndicator = document.getElementById('loading-indicator');
        this.errorToast = new bootstrap.Toast(document.getElementById('error-toast'));
        
        this.initializeEventListeners();
        this.focusInput();
    }

    initializeEventListeners() {
        // Form submission
        this.chatForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendMessage();
        });

        // Character counter
        this.messageInput.addEventListener('input', () => {
            this.updateCharCounter();
        });

        // Enter key support
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Auto-resize input on mobile
        this.messageInput.addEventListener('focus', () => {
            if (window.innerWidth <= 768) {
                setTimeout(() => {
                    this.scrollToBottom();
                }, 300);
            }
        });
    }

    updateCharCounter() {
        const length = this.messageInput.value.length;
        this.charCounter.textContent = length;
        
        // Change color based on character limit
        if (length > 450) {
            this.charCounter.className = 'text-warning';
        } else if (length >= 500) {
            this.charCounter.className = 'text-danger';
        } else {
            this.charCounter.className = '';
        }
    }

    async sendMessage() {
        const message = this.messageInput.value.trim();
        
        if (!message) {
            this.showError('Por favor, escribe un mensaje antes de enviarlo.');
            return;
        }

        if (message.length > 500) {
            this.showError('El mensaje es demasiado largo. Máximo 500 caracteres.');
            return;
        }

        // Disable form while processing
        this.setFormEnabled(false);
        this.showLoading(true);

        try {
            // Add user message to chat immediately
            this.addMessage(message, 'user');
            this.clearInput();

            // Show typing indicator
            this.showTypingIndicator();

            // Send message to server
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            if (data.error) {
                throw new Error(data.error);
            }

            // Remove typing indicator
            this.hideTypingIndicator();

            // Add bot response
            setTimeout(() => {
                this.addMessage(data.bot_response, 'bot');
            }, 500); // Small delay for better UX

        } catch (error) {
            console.error('Error sending message:', error);
            this.hideTypingIndicator();
            this.showError(error.message || 'Error al enviar el mensaje. Inténtalo de nuevo.');
        } finally {
            this.setFormEnabled(true);
            this.showLoading(false);
            this.focusInput();
        }
    }

    addMessage(content, sender) {
        const timestamp = new Date().toLocaleTimeString('es-ES', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message message-animate mb-3`;

        if (sender === 'user') {
            messageDiv.innerHTML = `
                <div class="d-flex align-items-start justify-content-end">
                    <div class="message-content me-3">
                        <div class="message-bubble bg-info text-white p-3 rounded">
                            ${this.escapeHtml(content)}
                        </div>
                        <small class="text-muted mt-1 d-block text-end">${timestamp}</small>
                    </div>
                    <div class="avatar">
                        <div class="rounded-circle bg-info text-white d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
            `;
        } else {
            messageDiv.innerHTML = `
                <div class="d-flex align-items-start">
                    <div class="avatar me-3">
                        <div class="rounded-circle bg-info text-white d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                            <i class="fas fa-robot"></i>
                        </div>
                    </div>
                    <div class="message-content">
                        <div class="message-bubble bg-secondary text-white p-3 rounded">
                            ${this.escapeHtml(content)}
                        </div>
                        <small class="text-muted mt-1 d-block">${timestamp}</small>
                    </div>
                </div>
            `;
        }

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }

    showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.className = 'message bot-message mb-3';
        typingDiv.innerHTML = `
            <div class="d-flex align-items-start">
                <div class="avatar me-3">
                    <div class="rounded-circle bg-info text-white d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                        <i class="fas fa-robot"></i>
                    </div>
                </div>
                <div class="message-content">
                    <div class="message-bubble bg-secondary text-white p-3 rounded">
                        <div class="typing-dots">
                            <div class="typing-dot"></div>
                            <div class="typing-dot"></div>
                            <div class="typing-dot"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.chatMessages.appendChild(typingDiv);
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    setFormEnabled(enabled) {
        this.messageInput.disabled = !enabled;
        this.sendButton.disabled = !enabled;
        
        if (enabled) {
            this.sendButton.innerHTML = `
                <i class="fas fa-paper-plane"></i>
                <span class="d-none d-md-inline ms-2">Enviar</span>
            `;
        } else {
            this.sendButton.innerHTML = `
                <div class="spinner-border spinner-border-sm" role="status">
                    <span class="visually-hidden">Enviando...</span>
                </div>
                <span class="d-none d-md-inline ms-2">Enviando...</span>
            `;
        }
    }

    showLoading(show) {
        if (show) {
            this.loadingIndicator.classList.remove('d-none');
        } else {
            this.loadingIndicator.classList.add('d-none');
        }
    }

    showError(message) {
        document.getElementById('error-message').textContent = message;
        this.errorToast.show();
    }

    clearInput() {
        this.messageInput.value = '';
        this.updateCharCounter();
    }

    focusInput() {
        // Small delay to ensure proper focus on mobile devices
        setTimeout(() => {
            this.messageInput.focus();
        }, 100);
    }

    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }

    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, (m) => map[m]);
    }
}

// Initialize the chatbot when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new SpanishChatbot();
});

// Handle page visibility for better mobile experience
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        // Page became visible, scroll to bottom
        setTimeout(() => {
            const chatMessages = document.getElementById('chat-messages');
            if (chatMessages) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        }, 100);
    }
});
