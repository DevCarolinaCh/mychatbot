# Chatbot Español

Un chatbot web en español construido con Flask que proporciona conversaciones interactivas usando reconocimiento de patrones.

## Características

- 🤖 Chatbot inteligente en español con respuestas contextuales
- 💬 Interfaz de chat en tiempo real
- 📱 Diseño responsive (funciona en móvil y escritorio)
- 🌙 Tema oscuro moderno con Bootstrap
- ✨ Indicadores de escritura y animaciones
- 🔤 Contador de caracteres
- ⚡ Manejo de errores robusto

## Instalación Local

### Prerrequisitos

- Python 3.11 o superior
- pip (gestor de paquetes de Python)

### Pasos de instalación

1. **Clona o descarga este repositorio**
   ```bash
   git clone <url-del-repositorio>
   cd spanish-chatbot
   ```

2. **Crea un entorno virtual**
   ```bash
   python -m venv venv
   ```

3. **Activa el entorno virtual**
   - En Windows:
     ```bash
     venv\Scripts\activate
     ```
   - En macOS/Linux:
     ```bash
     source venv/bin/activate
     ```

4. **Instala las dependencias**
   ```bash
   pip install flask gunicorn
   ```

5. **Configura las variables de entorno (opcional)**
   ```bash
   # En Windows
   set SESSION_SECRET=tu-clave-secreta-aqui
   
   # En macOS/Linux
   export SESSION_SECRET=tu-clave-secreta-aqui
   ```

6. **Ejecuta la aplicación**
   ```bash
   python main.py
   ```

7. **Abre tu navegador**
   Ve a `http://localhost:5000` para usar el chatbot.

## Estructura del Proyecto

```
spanish-chatbot/
├── main.py              # Aplicación principal Flask
├── templates/
│   └── index.html       # Interfaz HTML del chat
├── static/
│   ├── css/
│   │   └── style.css    # Estilos personalizados
│   └── js/
│       └── chat.js      # Lógica JavaScript del chat
├── README.md            # Este archivo
└── .env.example         # Ejemplo de variables de entorno
```

## Desarrollo en VSCode

### Extensiones recomendadas

- Python (Microsoft)
- Flask Snippets
- HTML CSS Support
- JavaScript (ES6) code snippets
- Prettier - Code formatter

### Configuración de VSCode

1. Abre la carpeta del proyecto en VSCode
2. Selecciona el intérprete de Python del entorno virtual:
   - Ctrl+Shift+P → "Python: Select Interpreter"
   - Selecciona el Python de tu carpeta `venv`

### Ejecución y debugging

1. **Para ejecutar en modo desarrollo:**
   ```bash
   python main.py
   ```

2. **Para debugging en VSCode:**
   - Crear `.vscode/launch.json`:
   ```json
   {
       "version": "0.2.0",
       "configurations": [
           {
               "name": "Python: Flask",
               "type": "python",
               "request": "launch",
               "program": "${workspaceFolder}/main.py",
               "env": {
                   "FLASK_ENV": "development"
               },
               "console": "integratedTerminal"
           }
       ]
   }
   ```

## Uso del Chatbot

El chatbot responde a diferentes tipos de mensajes en español:

- **Saludos**: "hola", "buenos días", "buenas tardes"
- **Estado**: "cómo estás", "qué tal", "cómo andas"
- **Despedidas**: "adiós", "hasta luego", "nos vemos"
- **Agradecimientos**: "gracias", "muchas gracias"
- **Preguntas personales**: "cómo te llamas", "quién eres"
- **Solicitudes de ayuda**: "ayuda", "ayúdame"
- **Temas diversos**: clima, comida, entretenimiento, etc.

## Personalización

### Añadir nuevos patrones de respuesta

Edita la clase `SpanishChatbot` en `main.py` y agrega nuevos patrones en el diccionario `self.patterns`.

### Modificar el diseño

- **CSS**: Edita `static/css/style.css`
- **HTML**: Modifica `templates/index.html`
- **JavaScript**: Actualiza `static/js/chat.js`

## Solución de problemas

### Error: Puerto ya en uso
```bash
# Mata el proceso que usa el puerto 5000
# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# macOS/Linux:
lsof -ti:5000 | xargs kill
```

### Error: Módulo Flask no encontrado
```bash
# Asegúrate de estar en el entorno virtual activado
pip install flask gunicorn
```

## Contribución

1. Haz un fork del proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-caracteristica`)
3. Commit tus cambios (`git commit -am 'Añade nueva característica'`)
4. Push a la rama (`git push origin feature/nueva-caracteristica`)
5. Crea un Pull Request

## Licencia

Este proyecto es de código abierto y está disponible bajo la Licencia MIT.