import os
import logging
from flask import Flask, request, render_template, jsonify
import re

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

class SpanishChatbot:
    def __init__(self):
        # Enhanced Spanish conversation patterns
        self.patterns = {
            # Greetings
            r'\b(hola|buenas|buenos días|buenas tardes|buenas noches|hey|ey)\b': [
                "¡Hola! ¿Cómo estás hoy?",
                "¡Buenas! ¿En qué puedo ayudarte?",
                "¡Hola! Me alegra verte por aquí.",
                "¡Saludos! ¿Cómo va tu día?"
            ],
            
            # How are you
            r'\b(cómo estás|qué tal|cómo andas|cómo te va)\b': [
                "¡Muy bien, gracias por preguntar! ¿Y tú cómo estás?",
                "Todo perfecto por aquí. ¿Cómo te sientes hoy?",
                "¡Excelente! ¿En qué puedo ayudarte?",
                "De maravilla, gracias. ¿Qué tal tu día?"
            ],
            
            # Goodbyes
            r'\b(adiós|hasta luego|nos vemos|chau|bye|hasta la vista)\b': [
                "¡Hasta luego! Que tengas un excelente día.",
                "¡Nos vemos! Fue un placer conversar contigo.",
                "¡Adiós! Vuelve cuando quieras.",
                "¡Hasta la próxima! Cuídate mucho."
            ],
            
            # Thanks
            r'\b(gracias|muchas gracias|te agradezco|mil gracias)\b': [
                "¡De nada! Es un placer ayudarte.",
                "No hay de qué. ¡Para eso estoy aquí!",
                "¡Con mucho gusto! ¿Algo más en lo que pueda ayudar?",
                "¡Encantado de ayudar!"
            ],
            
            # Name questions
            r'\b(cómo te llamas|cuál es tu nombre|quién eres)\b': [
                "Soy un chatbot en español. ¡Puedes llamarme ChatBot!",
                "Me llamo ChatBot y estoy aquí para conversar contigo en español.",
                "Soy tu asistente virtual en español. ¿Cómo te llamas tú?",
                "Mi nombre es ChatBot. ¡Mucho gusto!"
            ],
            
            # Help requests
            r'\b(ayuda|ayúdame|necesito ayuda|puedes ayudar)\b': [
                "¡Por supuesto! Estoy aquí para ayudarte. ¿Qué necesitas?",
                "¡Claro que sí! Dime en qué puedo asistirte.",
                "¡Con mucho gusto! ¿En qué puedo ser de utilidad?",
                "¡Cuenta conmigo! ¿Qué te gustaría saber?"
            ],
            
            # Weather
            r'\b(clima|tiempo|lluvia|sol|calor|frío)\b': [
                "No puedo consultar el clima actual, pero espero que tengas buen tiempo.",
                "¡Ojalá tengas un día soleado! ¿Te gusta más el sol o la lluvia?",
                "El clima siempre es tema de conversación. ¿Cómo está por tu zona?",
                "No tengo información del clima, pero espero que sea perfecto para ti."
            ],
            
            # Food
            r'\b(comida|comer|hambre|restaurante|cocinar)\b': [
                "¡Me encanta hablar de comida! ¿Cuál es tu plato favorito?",
                "La comida es uno de los grandes placeres de la vida. ¿Te gusta cocinar?",
                "¡Qué rico! ¿Qué tipo de cocina prefieres?",
                "Hablar de comida siempre me da hambre virtual. ¿Cuál es tu restaurante favorito?"
            ],
            
            # Entertainment
            r'\b(música|canción|película|libro|leer|escuchar)\b': [
                "¡El entretenimiento es genial! ¿Qué tipo de música te gusta?",
                "Me parece interesante. ¿Tienes alguna recomendación?",
                "¡Qué bueno! El arte y la cultura enriquecen nuestras vidas.",
                "¡Excelente tema! ¿Cuál fue la última película que viste?"
            ]
        }
        
        # Default responses for unmatched inputs
        self.default_responses = [
            "Interesante. ¿Puedes contarme más sobre eso?",
            "Me parece muy bien. ¿Qué opinas tú?",
            "¡Qué bueno! ¿Te gustaría hablar de algo más específico?",
            "Entiendo. ¿Hay algo en particular que te interese?",
            "¡Genial! Sigue contándome.",
            "Es un tema fascinante. ¿Qué más puedes decirme?",
            "¡Qué interesante perspectiva! ¿Cómo llegaste a esa conclusión?",
            "Me gusta tu punto de vista. ¿Qué te hizo pensar en eso?"
        ]
    
    def get_response(self, message):
        """Generate a response based on the user's message"""
        message = message.lower().strip()
        
        # Check each pattern
        for pattern, responses in self.patterns.items():
            if re.search(pattern, message, re.IGNORECASE):
                import random
                return random.choice(responses)
        
        # If no pattern matches, return a default response
        import random
        return random.choice(self.default_responses)

# Initialize chatbot
chatbot = SpanishChatbot()

@app.route("/")
def index():
    """Render the main chat interface"""
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    """Handle chat messages via AJAX"""
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "Mensaje requerido"}), 400
        
        user_message = data["message"].strip()
        if not user_message:
            return jsonify({"error": "El mensaje no puede estar vacío"}), 400
        
        # Generate bot response
        bot_response = chatbot.get_response(user_message)
        
        return jsonify({
            "user_message": user_message,
            "bot_response": bot_response,
            "success": True
        })
    
    except Exception as e:
        app.logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            "error": "Lo siento, hubo un error procesando tu mensaje. Inténtalo de nuevo."
        }), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template("index.html"), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    app.logger.error(f"Internal server error: {str(error)}")
    return jsonify({"error": "Error interno del servidor"}), 500

if __name__ == "__main__":
    # Configurar puerto desde variable de entorno o usar 5000 por defecto
    port = int(os.environ.get("PORT", 5000))
    host = os.environ.get("HOST", "0.0.0.0")
    
    # Ejecutar en modo debug para desarrollo local
    app.run(host=host, port=port, debug=True)
